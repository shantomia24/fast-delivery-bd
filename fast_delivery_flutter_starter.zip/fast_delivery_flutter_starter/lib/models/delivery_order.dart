class DeliveryOrder {
  final String trackingId;
  final String senderName;
  final String senderPhone;
  final String pickupAddress;
  final String receiverName;
  final String receiverPhone;
  final String deliveryAddress;
  final double weightKg;
  final String paymentMethod;
  final String orderStatus;
  final DateTime createdAt;
  final String? customerId;
  final String? riderId;
  final double? distanceKm;
  final int? deliveryCharge;

  DeliveryOrder({
    required this.trackingId,
    required this.senderName,
    required this.senderPhone,
    required this.pickupAddress,
    required this.receiverName,
    required this.receiverPhone,
    required this.deliveryAddress,
    required this.weightKg,
    required this.paymentMethod,
    required this.orderStatus,
    required this.createdAt,
    this.customerId,
    this.riderId,
    this.distanceKm,
    this.deliveryCharge,
  });

  Map<String, dynamic> toMap() => {
    'trackingId': trackingId,
    'senderName': senderName,
    'senderPhone': senderPhone,
    'pickupAddress': pickupAddress,
    'receiverName': receiverName,
    'receiverPhone': receiverPhone,
    'deliveryAddress': deliveryAddress,
    'weightKg': weightKg,
    'paymentMethod': paymentMethod,
    'orderStatus': orderStatus,
    'createdAt': createdAt.toUtc().toIso8601String(),
    'customerId': customerId,
    'riderId': riderId,
    'distanceKm': distanceKm,
    'deliveryCharge': deliveryCharge,
  };
}
