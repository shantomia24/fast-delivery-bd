import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/delivery_order.dart';

class OrderService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Future<void> createOrder(DeliveryOrder order) async {
    await _db.collection('orders').doc(order.trackingId).set(order.toMap());
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> watchCustomerOrders(String customerId) {
    return _db.collection('orders')
      .where('customerId', isEqualTo: customerId)
      .orderBy('createdAt', descending: true)
      .snapshots();
  }

  Future<void> assignRider(String trackingId, String riderId) async {
    await _db.collection('orders').doc(trackingId).update({
      'riderId': riderId,
      'orderStatus': 'assigned',
    });
  }

  Future<void> updateOrderStatus(String trackingId, String status) async {
    await _db.collection('orders').doc(trackingId).update({
      'orderStatus': status,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }
}
