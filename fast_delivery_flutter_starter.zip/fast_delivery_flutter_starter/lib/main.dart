import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'models/delivery_order.dart';
import 'services/order_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Firebase চালু করতে FlutterFire CLI দিয়ে firebase_options.dart তৈরি করুন।
  // তারপর নিচের লাইনটি uncomment করে firebase_options.dart import করুন:
  // await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const FastDeliveryApp());
}

class FastDeliveryApp extends StatelessWidget {
  const FastDeliveryApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ফাস্ট ডেলিভারি',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF1769AA)),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF5F8FC),
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _tab = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      const CustomerHome(),
      const BookingScreen(),
      const TrackingScreen(),
      const ProfileScreen(),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('ফাস্ট ডেলিভারি', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        actions: [
          IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none)),
        ],
      ),
      body: pages[_tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (value) => setState(() => _tab = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'হোম'),
          NavigationDestination(icon: Icon(Icons.add_box_outlined), label: 'বুকিং'),
          NavigationDestination(icon: Icon(Icons.local_shipping_outlined), label: 'ট্র্যাক'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'প্রোফাইল'),
        ],
      ),
    );
  }
}

class CustomerHome extends StatelessWidget {
  const CustomerHome({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFF1769AA), Color(0xFF2699D6)]),
            borderRadius: BorderRadius.circular(20),
          ),
          child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('আপনার পার্সেল, আমাদের দায়িত্ব', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
              SizedBox(height: 8),
              Text('সারা বাংলাদেশে পণ্য ও পার্সেল ডেলিভারি', style: TextStyle(color: Colors.white)),
            ],
          ),
        ),
        const SizedBox(height: 20),
        const Text('আপনি কী করতে চান?', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        _ActionTile(icon: Icons.inventory_2_outlined, title: 'নতুন পার্সেল বুকিং', subtitle: 'পিকআপ ও ডেলিভারির তথ্য দিন'),
        _ActionTile(icon: Icons.location_searching, title: 'পার্সেল ট্র্যাক করুন', subtitle: 'ট্র্যাকিং নম্বর দিয়ে অবস্থা দেখুন'),
        _ActionTile(icon: Icons.calculate_outlined, title: 'ডেলিভারি চার্জ', subtitle: 'ওজন ও দূরত্ব অনুযায়ী চার্জ'),
        const SizedBox(height: 12),
        const Text('সেবা', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const Wrap(spacing: 8, runSpacing: 8, children: [
          Chip(label: Text('পার্সেল ডেলিভারি')),
          Chip(label: Text('পণ্য ডেলিভারি')),
          Chip(label: Text('ক্যাশ অন ডেলিভারি')),
        ]),
      ],
    );
  }
}

class _ActionTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  const _ActionTile({required this.icon, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) => Card(
    child: ListTile(
      leading: CircleAvatar(backgroundColor: const Color(0xFFE4F1FB), child: Icon(icon, color: const Color(0xFF1769AA))),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text(subtitle),
      trailing: const Icon(Icons.chevron_right),
    ),
  );
}

class BookingScreen extends StatefulWidget {
  const BookingScreen({super.key});
  @override
  State<BookingScreen> createState() => _BookingScreenState();
}

class _BookingScreenState extends State<BookingScreen> {
  final _formKey = GlobalKey<FormState>();
  final _sender = TextEditingController();
  final _senderPhone = TextEditingController();
  final _pickup = TextEditingController();
  final _receiver = TextEditingController();
  final _receiverPhone = TextEditingController();
  final _destination = TextEditingController();
  final _weight = TextEditingController();
  String _payment = 'cash';
  bool _saving = false;

  @override
  void dispose() {
    for (final c in [_sender, _senderPhone, _pickup, _receiver, _receiverPhone, _destination, _weight]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    try {
      final order = DeliveryOrder(
        trackingId: 'FD-${DateTime.now().millisecondsSinceEpoch}',
        senderName: _sender.text.trim(),
        senderPhone: _senderPhone.text.trim(),
        pickupAddress: _pickup.text.trim(),
        receiverName: _receiver.text.trim(),
        receiverPhone: _receiverPhone.text.trim(),
        deliveryAddress: _destination.text.trim(),
        weightKg: double.parse(_weight.text.trim()),
        paymentMethod: _payment,
        orderStatus: 'pending',
        createdAt: DateTime.now(),
      );
      // Firebase সংযুক্ত না করা পর্যন্ত অর্ডারটি শুধু ডিভাইসে তৈরি হবে না।
      // Firebase চালু হলে: await OrderService().createOrder(order);
      if (!mounted) return;
      showDialog(context: context, builder: (_) => AlertDialog(
        title: const Text('বুকিং তথ্য প্রস্তুত'),
        content: SelectableText('ট্র্যাকিং নম্বর:\n${order.trackingId}\n\nFirebase সংযোগের পর এটি অনলাইনে সংরক্ষিত হবে।'),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('ঠিক আছে'))],
      ));
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('তথ্য যাচাই করুন।')));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Widget _field(String label, TextEditingController controller, {bool number = false}) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: TextFormField(
      controller: controller,
      keyboardType: number ? const TextInputType.numberWithOptions(decimal: true) : TextInputType.text,
      decoration: InputDecoration(labelText: label, border: const OutlineInputBorder(), filled: true, fillColor: Colors.white),
      validator: (v) => (v == null || v.trim().isEmpty) ? 'এই ঘরটি পূরণ করুন' : null,
    ),
  );

  @override
  Widget build(BuildContext context) => Form(
    key: _formKey,
    child: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('নতুন পার্সেল বুকিং', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 16),
      const Text('প্রেরকের তথ্য', style: TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height: 10),
      _field('প্রেরকের নাম', _sender),
      _field('প্রেরকের মোবাইল', _senderPhone, number: true),
      _field('পিকআপ ঠিকানা', _pickup),
      const SizedBox(height: 8),
      const Text('প্রাপকের তথ্য', style: TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height: 10),
      _field('প্রাপকের নাম', _receiver),
      _field('প্রাপকের মোবাইল', _receiverPhone, number: true),
      _field('ডেলিভারি ঠিকানা', _destination),
      const SizedBox(height: 8),
      const Text('পার্সেলের তথ্য', style: TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height: 10),
      _field('ওজন (কেজি)', _weight, number: true),
      DropdownButtonFormField<String>(
        value: _payment,
        decoration: const InputDecoration(labelText: 'পেমেন্ট পদ্ধতি', border: OutlineInputBorder(), filled: true, fillColor: Colors.white),
        items: const [
          DropdownMenuItem(value: 'cash', child: Text('ক্যাশ অন ডেলিভারি')),
          DropdownMenuItem(value: 'bkash', child: Text('বিকাশ')),
          DropdownMenuItem(value: 'nagad', child: Text('নগদ')),
          DropdownMenuItem(value: 'rocket', child: Text('রকেট')),
        ],
        onChanged: (v) => setState(() => _payment = v ?? 'cash'),
      ),
      const SizedBox(height: 18),
      FilledButton.icon(
        onPressed: _saving ? null : _submit,
        icon: const Icon(Icons.send),
        label: Text(_saving ? 'অপেক্ষা করুন...' : 'বুকিং তথ্য জমা দিন'),
      ),
      const SizedBox(height: 8),
      const Text('নোট: প্রকৃত চার্জ নির্ধারণের জন্য দূরত্ব মাপা ও অ্যাডমিনের রেট সেটিংস যুক্ত করতে হবে।', style: TextStyle(color: Colors.black54)),
    ]),
  );
}

class TrackingScreen extends StatelessWidget {
  const TrackingScreen({super.key});
  @override
  Widget build(BuildContext context) => const Center(child: Padding(
    padding: EdgeInsets.all(24),
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      Icon(Icons.local_shipping_outlined, size: 64, color: Color(0xFF1769AA)),
      SizedBox(height: 12),
      Text('পার্সেল ট্র্যাকিং', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      SizedBox(height: 8),
      Text('আপনার অর্ডার বুকিংয়ের পর ট্র্যাকিং নম্বর দিয়ে পার্সেলের অবস্থা দেখতে পারবেন।', textAlign: TextAlign.center),
    ]),
  ));
}

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});
  @override
  Widget build(BuildContext context) => const Center(child: Text('প্রোফাইল ও লগইন ব্যবস্থা পরবর্তী ধাপে যুক্ত হবে।'));
}
